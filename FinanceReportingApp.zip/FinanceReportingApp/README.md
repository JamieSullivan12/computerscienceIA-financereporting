# WARNING: This program is still in its initial development phase

## Finance Reporting Project

The finance reporting project is a program to help finance businesses generate reports on their contracts and transactions.


## Build status.


#### Latest stable release
The latest stable code is located in the **main** branch. This is the recommended stable release, as it has been thoroughly tested.

#### Unstable developer branch
The latest test code is located in the **dev** branch. WARNING: This code has not been thoroughly tested and may experience bugs.

#### Experimental developer branch
Experimental additions to the code are located in the other branches. They may not be packaged and are very volatile. It is not reccomended this code is used until it moves to the **dev** or **main** branch.


#### Installation
Coming soon...