package jamiesullivan.packages.code.userinterface;

public class BlankLines {
	/**
	 * @return a string divider with "-" characters
	 */
	public static String get() {
		String blank = "\n\n\n\n";
		return blank;
	}
}
