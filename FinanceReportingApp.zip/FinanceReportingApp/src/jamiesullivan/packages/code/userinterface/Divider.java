package jamiesullivan.packages.code.userinterface;

public class Divider {
	
	/**
	 * @return a string divider with "-" characters
	 */
	public static String get() {
		String divider = "------------------------------------\n";
		return divider;
	}
}
