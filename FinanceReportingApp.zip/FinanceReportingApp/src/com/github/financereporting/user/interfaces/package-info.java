/**
 * 
 */
/**
 * @author jamie
 *
 */
package com.github.financereporting.user.interfaces;