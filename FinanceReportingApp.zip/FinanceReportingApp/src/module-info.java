module FinanceReportingApp {
	requires java.logging;
	requires java.desktop;
	requires java.base;

}